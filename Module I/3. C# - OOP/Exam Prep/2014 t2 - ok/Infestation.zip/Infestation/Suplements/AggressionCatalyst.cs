﻿namespace Infestation.Suplements
{
    public class AggressionCatalyst : Supplement
    {
        private const int PowerEff = 0;
        private const int HealthEff = 0;
        private const int AggressionEff = 3;

        public AggressionCatalyst()
            : base(PowerEff, HealthEff, AggressionEff)
        {
        }

        // check React to
    }
}
