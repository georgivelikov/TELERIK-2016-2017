﻿namespace Task_2___Events.Interfaces
{
    public interface IWriter
    {
        void Write(string message);

        void WriteLine(string message);
    }
}
