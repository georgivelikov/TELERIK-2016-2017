﻿namespace Task_2___Events.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
